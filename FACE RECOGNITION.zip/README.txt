HI! 
So this is my Facial Recognition model, based on Keras, TensorFlow and OpenCV.
this was my 1st time making anything like this, so had many problems, almost gave up as it took about 3 days, even after mentioning to some sources.
But here are some key things so that it can run on your PC,
as Tensorflow is incompatable with the latest version of python in vscode, so u hv to first change your python interpreter to older versions
here i used:-
 	Python version - 3.10.0
	TensorFlow version - 2.9.1
	Keras version - 2.9.0(comes with tensorflow when u install it)
	# numpy version - 1.21.6 # (IMPORTANT)
	OpenCV version - 4.10.0.84
	pip version -  21.2.3

make sure your tensorflow version is compatable with your python interpreter version, if that's good , 
then pls make sure to also check numpy too, it took a alot of timeto check where the problem was, 
it was actually numpy version in my case.
THATS IT!
IT WAS FUN!
